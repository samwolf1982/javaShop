/**
 * 
 */
package allClasses;

import javax.swing.DefaultComboBoxModel;

/**
 * @author sss
 *
 */
public class modelCombobox extends DefaultComboBoxModel {

}

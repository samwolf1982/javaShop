/**
 * 
 */


import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;

import javaxt.utils.Array;

import com.healthmarketscience.jackcess.Table;

import allClasses.ConectorOK;
import allClasses.datdabasetabmodel2;
import allClasses.newCar;

import java.awt.List;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Vector;

/**
 * @author Sam
 *
 */
public class TestWindow extends JDialog {
	
	String pathToFile= new File(".").getAbsolutePath()+"/Avto.mdb";
	private JTable table;
	  // Object[][] cellsData;
	  Object [][]cellsData;
	   Object[] cellsHeader;
	  
	
	 datdabasetabmodel2 model =null;
	public TestWindow() {
		getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 422, 251);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(233, 202, -182, -182);
		panel.add(scrollPane);
	//************************************	
	
		table = new JTable();
		table.setBounds(52, 42, 140, 120);
		panel.add(table);
		
		
	
		
		JButton btnClick = new JButton("Click");
		btnClick.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String query="select * from Cars";
				
				try {
					ConectorOK con=new ConectorOK(pathToFile, query);
					cellsHeader=con.getHeader();
					cellsData=con.getData();
					
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}

			// �������� ���				    			
		model=new datdabasetabmodel2(cellsData,cellsHeader);
		table.setModel(model);
				

			}
		});
		btnClick.setBounds(35, 217, 91, 23);
		panel.add(btnClick);
		
		JButton btnNewButton = new JButton("One row");
		// one row
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			try {
				ConectorOK con =new ConectorOK(pathToFile);
				
				String srt="SELECT Provider.nameof FROM Provider;";
		Object[] ov=	con.getSingleColumn(srt);
		
		for (Object obj : ov) {
		 System.out.println("Res: "+obj.toString());
		}
				
				
				
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
				
			
				
			}
		});
		btnNewButton.setBounds(203, 217, 91, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} 
			}
		});
		btnNewButton_1.setBounds(203, 168, 91, 23);
		panel.add(btnNewButton_1);
		setSize(613, 600);
	}
	/**
	 * ����� 2 ������� Vector    Object[]  --    ��� ����� ����������� !!!!
	 * @param stmt
	 * @param query
	 */
	/**
	 * @param stmt
	 * @param query
	 * @throws SQLException 
	 */
	public void filler(Statement stmt,String query  ) throws SQLException{
	
	
			  ArrayList<ArrayList<Object>> tempList=new ArrayList<ArrayList<Object>>();
		 
		        ResultSet rs = stmt.executeQuery(query);
		        //rs.last();        //    �������� � ��� ����� �����
		       // int countElement =rs.getRow();
		     //   rs.beforeFirst();
		        
		        // ���������� ���� �������
		        ResultSetMetaData rsmd = rs.getMetaData();
		      //cellsData=null;
		        
		    //  cellsHeader=null; 
		      cellsHeader=new Object[rsmd.getColumnCount()];
		        for (int i = 0; i <rsmd.getColumnCount(); i++) {
		        	
		        	String s=rsmd.getColumnName(i+1);
		        	
		        	//String s=rsmd.get(i);  
		        	cellsHeader[i]="55";
				          
				          // ���������� �����   	                ���������� ��������    Object[][]    Object[] 
					       while (rs.next()) {    
					      //  Object[] record = new Object[rsmd.getColumnCount()];
					    		ArrayList<Object> tempListRow=new ArrayList<Object>();	
					    		int cou=rsmd.getColumnCount();
					        for (int j = 1; j <= cou; j++) {
					        	
					        	
					        	//System.out.println("SQL TYPE: "+rs.getType());
					        	String res="";
					        	if(rs.getObject(j)!=null){
					        		 res=rs.getObject(j).toString();
					        	}
					        	
					          tempListRow.add(res );
					         // cellsData[i][j] = rs.getString(j).toString();
					          }
					        tempList.add(tempListRow);					          
		         	}   
		      
		        }
		        
		        
		        cellsData=new Object[tempList.size()][ tempList.get(0).size()];// ������ �������
		        // �� ������ � ������ ��� �������
		    for (int i = 0; i < tempList.size(); i++) {
				for (int j = 0; j < tempList.get(0).size(); j++) {
					cellsData[i][j]=tempList.get(i).get(j);
					
				}
		    	  
			}
		        
		        
		  
	}
	
	
	public void fillerCopy(Statement stmt,String query  ){
		
		  try {
			  ArrayList<ArrayList<Object>> tempList=new ArrayList<ArrayList<Object>>();
		 
		        ResultSet rs = stmt.executeQuery(query);
		        //rs.last();        //    �������� � ��� ����� �����
		       // int countElement =rs.getRow();
		     //   rs.beforeFirst();
		        
		        // ���������� ���� �������
		        ResultSetMetaData rsmd = rs.getMetaData();
		      //cellsData=null;
		        
		    //  cellsHeader=null; 
		      cellsHeader=new Object[rsmd.getColumnCount()];
		        for (int i = 0; i <rsmd.getColumnCount(); i++) {
		        	
		        	//String s=rsmd.getColumnName(i+1);
		        	
		        	//String s=rsmd.get(i);  
		        	cellsHeader[i]="55";
				          
				          // ���������� �����   	                ���������� ��������    Object[][]    Object[] 
					       while (rs.next()) {    
					      //  Object[] record = new Object[rsmd.getColumnCount()];
					    		ArrayList<Object> tempListRow=new ArrayList<Object>();	
					    		int cou=rsmd.getColumnCount();
					        for (int j = 1; j <= cou; j++) {
					        	
					        	
					        	//System.out.println("SQL TYPE: "+rs.getType());
					        	String res=rs.getObject(j).toString();
					          tempListRow.add(res );
					         // cellsData[i][j] = rs.getString(j).toString();
					          }
					        tempList.add(tempListRow);					          
		         	}   
		      
		        }
		        
		        
		        cellsData=new Object[tempList.size()][ tempList.get(0).size()];// ������ �������
		        // �� ������ � ������ ��� �������
		    for (int i = 0; i < tempList.size(); i++) {
				for (int j = 0; j < tempList.get(0).size(); j++) {
					cellsData[i][j]=tempList.get(i).get(j);
					
				}
		    	  
			}
		        
		        
		    } catch (SQLException e ) {
		     
		    	System.out.println("Catch SQL EXCP Error: "+e.getMessage());
		    	
		    }
	}
		
	public static DefaultTableModel buildTableModel(ResultSet rs)
	        throws SQLException {

	    ResultSetMetaData metaData = rs.getMetaData();

	    // names of columns
	    Vector<String> columnNames = new Vector<String>();
	    int columnCount = metaData.getColumnCount();
	    for (int column = 1; column <= columnCount; column++) {
	        columnNames.add(metaData.getColumnName(column));
	    }

	    // data of the table
	    Vector<Vector<Object>> data = new Vector<Vector<Object>>();
	    while (rs.next()) {
	        Vector<Object> vector = new Vector<Object>();
	        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
	            vector.add(rs.getObject(columnIndex));
	        }
	        data.add(vector);
	    }

	    return new DefaultTableModel(data, columnNames);

	}
}
